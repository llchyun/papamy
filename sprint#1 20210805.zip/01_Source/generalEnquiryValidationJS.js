function getCustomProperties(formaParam, sendParam) {
    Debug.print('************** generalEnquiryReportValidationJS ****************');
    
    var customPropObj = {
        txt_others: {},
        txt_Attn_1: {},
        txt_Attn_2: {},
        txt_Attn_3: {},
        chk_installation: {},
        chk_stock: {},
        ddl_remote_mode: {},
        ddl_fanspeed: {},
        ddl_A2W_mode: {},
        ddl_freq: {},
        txt_environment: {},
        txt_length: {},
        txt_elevation: {},
        txt_gas: {},
        txt_liquid: {},
        rd_water_supply: {},
        txt_operation: {},
        txt_standby: {},
        txt_run_current: {},
        txt_supply_freq: {},
        txt_room_ambient: {},
        txt_outdoor_ambient: {},
        ddl_ac_discharge: {},
        ddl_ac_suction: {},
        ddl_air_filter: {},
        ddl_evaporator: {},
        ddl_condenser: {}
    };
    if(formaParam.temporaryFlag == '0'){
	    if ((sendParam['customValidation'] != 'false') && (sendParam['customValidation'] == null)) {
		    if (checkDefsValue(sendParam['chk_defects'])) {
		        customPropObj['txt_others'][FRItems.PROP_REQUIRED] = true;
		    }
		    if (sendParam['ddl_att_to_1'] != '') {
		        customPropObj['txt_Attn_1'][FRItems.PROP_REQUIRED] = true;
		    }
		    if (sendParam['ddl_att_to_2'] != '') {
		        customPropObj['txt_Attn_2'][FRItems.PROP_REQUIRED] = true;
		    }
		    if (sendParam['ddl_att_to_3'] != '') {
		        customPropObj['txt_Attn_3'][FRItems.PROP_REQUIRED] = true;
		    }
		    if (sendParam['rd_unit_claim'] == '1') {
		    	if(sendParam['chk_installation'] != '1' && sendParam['chk_stock'] != '1'){
		    		customPropObj['chk_installation'][FRItems.PROP_REQUIRED] = true;
		    		customPropObj['chk_stock'][FRItems.PROP_REQUIRED] = true;
		    	}
		    }
		    if (sendParam['cbRemoteContModeNA'] != '1') {
		        customPropObj['ddl_remote_mode'][FRItems.PROP_REQUIRED] = true;
		    }
		    if (sendParam['cbFanSpeedNA'] != '1') {
		        customPropObj['ddl_fanspeed'][FRItems.PROP_REQUIRED] = true;
		    }
		    if(sendParam['rd_prd_cate'] == '3'){
			     if (sendParam['cboA2WModeNA'] != '1') {
			    	 customPropObj['ddl_A2W_mode'][FRItems.PROP_REQUIRED] = true;
			     }
			     if (sendParam['cboA2WFreqOccNA'] != '1') {
			    	 customPropObj['ddl_freq'][FRItems.PROP_REQUIRED] = true;
			     }
			     if (sendParam['cbA2WInstEnvLocNA'] != '1') {
			    	 customPropObj['txt_environment'][FRItems.PROP_REQUIRED] = true;
			     }
		    }
		    if (sendParam['rbPipeLengthRemark'] != '1' && sendParam['rbPipeLengthRemark'] != '2') {
		        customPropObj['txt_length'][FRItems.PROP_REQUIRED] = true;
		    }
		    if (sendParam['rbPipeElevRemark'] != '1' && sendParam['rbPipeElevRemark'] != '2') {
		        customPropObj['txt_elevation'][FRItems.PROP_REQUIRED] = true;
		    }
		    if (sendParam['rbGasPressureRemark'] != '1' && sendParam['rbGasPressureRemark'] != '2') {
		        customPropObj['txt_gas'][FRItems.PROP_REQUIRED] = true;
		    }
		    if (sendParam['rbLiqPressureRemark'] != '1' && sendParam['rbLiqPressureRemark'] != '2') {
		        customPropObj['txt_liquid'][FRItems.PROP_REQUIRED] = true;
		    }
		    if (sendParam['rbWaterSupCondNA'] != '1' && sendParam['rbWaterSupCondNA'] != '2') {
		        customPropObj['rd_water_supply'][FRItems.PROP_REQUIRED] = true;
		    }
		    if (sendParam['rbUnitOperationNA'] != '1' && sendParam['rbUnitOperationNA'] != '2') {
		        customPropObj['txt_operation'][FRItems.PROP_REQUIRED] = true;
		    }
		    if (sendParam['rbUnitStandByNA'] != '1' && sendParam['rbUnitStandByNA'] != '2') {
		        customPropObj['txt_standby'][FRItems.PROP_REQUIRED] = true;
		    }
		    if (sendParam['rbRunCurrentNA'] != '1' && sendParam['rbRunCurrentNA'] != '2') {
		        customPropObj['txt_run_current'][FRItems.PROP_REQUIRED] = true;
		    }
		    if (sendParam['rbSupFreqNA'] != '1' && sendParam['rbSupFreqNA'] != '2') {
		        customPropObj['txt_supply_freq'][FRItems.PROP_REQUIRED] = true;
		    }
		    if (sendParam['rbRoomAmbientNA'] != '1' && sendParam['rbRoomAmbientNA'] != '2') {
		        customPropObj['txt_room_ambient'][FRItems.PROP_REQUIRED] = true;
		    }
		    if (sendParam['rbOutdoorAmbientNA'] != '1' && sendParam['rbOutdoorAmbientNA'] != '2') {
		        customPropObj['txt_outdoor_ambient'][FRItems.PROP_REQUIRED] = true;
		    }
		    if (sendParam['rbACDiscAirNA'] != '1' && sendParam['rbACDiscAirNA'] != '2') {
		        customPropObj['ddl_ac_discharge'][FRItems.PROP_REQUIRED] = true;
		    }
		    if (sendParam['rbACSuctionAirNA'] != '1' && sendParam['rbACSuctionAirNA'] != '2') {
		        customPropObj['ddl_ac_suction'][FRItems.PROP_REQUIRED] = true;
		    }
		    if (sendParam['cboAirFilterConNA'] != '1') {
		        customPropObj['ddl_air_filter'][FRItems.PROP_REQUIRED] = true;
		    }
		    if (sendParam['cboEvaporatorNa'] != '1') {
		        customPropObj['ddl_evaporator'][FRItems.PROP_REQUIRED] = true;
		    }
		    if (sendParam['cboCondenserNA'] != '1') {
		        customPropObj['ddl_condenser'][FRItems.PROP_REQUIRED] = true;
		    }
	    }
	    
	}
    


    return {
        error: false,
        data: customPropObj
    };
}

function validate(formaParam, sendParam, resultObj) {
    Debug.print('************** 入力チェックサンプルプログラム：ユーザバリデーション実行 ****************');
    
    
    var errorMessage = '';
    if(formaParam.temporaryFlag == '0'){
	    // 入力チェック(1) フィールド識別ID「sample_field_1」に対するチェック
	    if ((sendParam['customValidation'] != 'false') && (sendParam['customValidation'] == null)) {
		    if (sendParam['cbTempSettingNA'] != '1') {
		    	if(sendParam['ddl_remote_mode'] == '4'){
		        	if(sendParam['txt_temp'] != '7'){
		        		if(sendParam['txt_temp'] != '10'){
			        		errorMessage = 'Fan Only Mode temperature must either 7 or 10';
					        // 返却オブジェクトにエラー情報を設定
					        ImFormaUtil.addValidationError(resultObj, errorMessage, 'check6', ['txt_temp']);
		        		}
		        	}
			    }else{
			        if(checkTemp(sendParam['txt_temp'])) {
				    	errorMessage = 'Temperature must higher or equal to 16 smaller or equal to 30';
				        // 返却オブジェクトにエラー情報を設定
				        ImFormaUtil.addValidationError(resultObj, errorMessage, 'check1', ['txt_temp']);
				    }
		        }
		     }
		     
		     if(sendParam['rd_prd_cate'] == '3'){
			     if (sendParam['cbA2WNA'] != '1') {
			        if(checkTemp(sendParam['txt_water_out'])) {
				    	errorMessage = 'Temperature must higher or equal to 16 smaller or equal to 30';
				        // 返却オブジェクトにエラー情報を設定
				        ImFormaUtil.addValidationError(resultObj, errorMessage, 'check2', ['txt_water_out']);
				    }
			     }
		     }
		     
		     if(sendParam['rd_prd_cate'] == '3'){
			     if (sendParam['cboA2WTankSetTempNA'] != '1') {
			        if(checkTemp(sendParam['txt_tank_temp'])) {
				    	errorMessage = 'Temperature must higher or equal to 16 smaller or equal to 30';
				        // 返却オブジェクトにエラー情報を設定
				        ImFormaUtil.addValidationError(resultObj, errorMessage, 'check3', ['txt_tank_temp']);
				    }
			     }
		     }
		     
		     
	//	     if (sendParam['rbRoomAmbientNA'] != '1') {
	//	        if(checkTemp(sendParam['txt_room_ambient'])) {
	//		    	errorMessage = 'Temperature must higher or equal to 16 smaller or equal to 30';
	//		        // 返却オブジェクトにエラー情報を設定
	//		        ImFormaUtil.addValidationError(resultObj, errorMessage, 'check4', ['txt_room_ambient']);
	//		    }
	//	     }
	//	     
	//	     if (sendParam['rbOutdoorAmbientNA'] != '1') {
	//	        if(checkTemp(sendParam['txt_outdoor_ambient'])) {
	//		    	errorMessage = 'Temperature must higher or equal to 16 smaller or equal to 30';
	//		        // 返却オブジェクトにエラー情報を設定
	//		        ImFormaUtil.addValidationError(resultObj, errorMessage, 'check5', ['txt_outdoor_ambient']);
	//		    }
	//	     }
	     }
    }
    
     
    
    // 返却オブジェクトを返却
    return resultObj;
}

function checkTemp(inputValue) {
    // 「sample_field_1」に対する入力チェック処理を実装する。
	if(inputValue >= 16 && inputValue <= 30){
		return false;
	}else{
		return true;
	}
}

function checkDefsValue(inputValue) {
    // 「sample_field_1」に対する入力チェック処理を実装する。
	if(inputValue != null){
		var n2 = '12';
		var n3 = inputValue.indexOf(n2) !== -1;
		
		return n3;
	}else{
		return false;
	}
}

function checkOtherValue(inputValue) {
    // 「sample_field_1」に対する入力チェック処理を実装する。
	if(inputValue == ''){
		return true;
	}else{
		return false;
	}
}

function getErrorDisplayOrder(formaParam) {
    Debug.print('************** 入力チェックサンプルプログラム：エラーメッセージ表示順を指定 ****************');
    var arry = [];

    //標準で提供する入力チェックによるメッセージ
    //フィールド識別ID「sample_field_1」
    // 【◎】IM-FormaDesigner for Accel Platform 2013 Summer (8.0.4)以前
    // arry.push(ImFormaUtil.getItemIdById('sample_field_1'));
    // arry.push(ImFormaUtil.getItemIdById('sample_field_3'));

    // 【◎】IM-FormaDesigner for Accel Platform 2013 Winter (8.0.5)以降　getItemIdByIdは非推奨です。
    //arry.push(ImFormaUtil.getItemIdById4Proc('txt_others', formaParam.processKey));
    //arry.push(ImFormaUtil.getItemIdById4Proc('sample_field_3', formaParam.processKey));

    //標準で提供する入力チェックによるメッセージ（ファイルアップロードアイテムの場合）
    //arry.push(ImFormaUtil.getItemIdById(ImFormaUtil.getFileUploadId(0)));

    // validate メソッドで行われる入力チェックによるメッセージ
    //入力チェックID「check1」
    arry.push('check1');
    arry.push('check2');
    arry.push('check3');
//    arry.push('check4');
//    arry.push('check5');
    arry.push('check6');

    return arry;
}