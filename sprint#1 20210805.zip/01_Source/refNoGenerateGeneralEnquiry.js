function createControllCode(autoNoParam, sendParam) {
	Debug.print('************** adHocRefNo JS ****************');
	
	var today = new Date();
	var dd = today.getDate();
	var mm = today.getMonth()+1; //January is 0!
	var yyyy = today.getFullYear();
	
	if(dd<10) {
	    dd = '0'+dd
	} 
	
	if(mm<10) {
	    mm = '0'+mm
	} 
	
	var yearMonth = yyyy + mm;
	var prd_cate = "";
	if(sendParam['rd_prd_cate'] != ""){
		if(sendParam['rd_prd_cate'] == "1"){
			prd_cate = "RAC";
		}
		if(sendParam['rd_prd_cate'] == "2"){
			prd_cate = "CAC";
		}
		if(sendParam['rd_prd_cate'] == "3"){
			prd_cate = "A2W";
		}
	}
	var txt_ref_no = yearMonth + "-" + prd_cate + "-G";
	Debug.print('txt_ref_no: '+txt_ref_no );
	Debug.print('************** adHocRefNo JS END ****************');
	return {"error" : false, data : txt_ref_no};
}